export default function Programs() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-2">Our Programs</h2>
      <p className="text-gray-700">List of training and educational programs will appear here. [Placeholder]</p>
    </div>
  );
}