export default function Home() {
  return (
    <div className="p-6 text-center">
      <h2 className="text-3xl font-bold mb-4">Welcome to Cathund Digital Center</h2>
      <p className="text-lg text-gray-700">Empowering education through technology. Placeholder content here.</p>
    </div>
  );
}