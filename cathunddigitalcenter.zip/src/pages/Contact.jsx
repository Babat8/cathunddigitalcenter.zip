export default function Contact() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-2">Contact Us</h2>
      <p className="text-gray-700">Feel free to reach out through our contact form. [Placeholder]</p>
    </div>
  );
}